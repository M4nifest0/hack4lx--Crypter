﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' Allgemeine Informationen über eine Assembly werden über die folgenden 
' Attribute gesteuert. Ändern Sie diese Attributwerte, um die Informationen zu ändern,
' die mit einer Assembly verknüpft sind.

' Die Werte der Assemblyattribute überprüfen

<Assembly: AssemblyTitle("35j45jh3j4r89934rhjfh839h")> 
<Assembly: AssemblyDescription("34jh32f82h3g23252g32g")> 
<Assembly: AssemblyCompany("23g8023uyg23hj230hg32")> 
<Assembly: AssemblyProduct("35h32f32t3723k1j3kl123131")> 
<Assembly: AssemblyCopyright("1321dasdasdase24")> 
<Assembly: AssemblyTrademark("1d32r12r12d12e4")> 

<Assembly: ComVisible(False)>

'Die folgende GUID bestimmt die ID der Typbibliothek, wenn dieses Projekt für COM verfügbar gemacht wird
<Assembly: Guid("66811ef9-7ce4-4983-b0e3-1424c24a23dc")> 

' Versionsinformationen für eine Assembly bestehen aus den folgenden vier Werten:
'
'      Hauptversion
'      Nebenversion 
'      Buildnummer
'      Revision
'
' Sie können alle Werte angeben oder die standardmäßigen Build- und Revisionsnummern 
' übernehmen, indem Sie "*" eingeben:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("4124.231.1231.123")> 
<Assembly: AssemblyFileVersion("4223.23.123.533")> 
